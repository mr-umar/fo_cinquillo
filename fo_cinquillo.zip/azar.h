// Este fichero se le da al alumno
#ifndef AZAR_H 
#define	AZAR_H

void inicializar_azar();
int numero_al_azar(int max);

#endif	/* AZAR_H */

