// mesa.h
#ifndef MESA_H
#define MESA_H

#include "carta.h"  // Incluye las definiciones de NUM_NUMS y NUM_PALS

#define TRUE 1
#define FALSE 0

void imprimir_mantel(int mantel[NUM_NUMS][NUM_PALS]);

#endif
