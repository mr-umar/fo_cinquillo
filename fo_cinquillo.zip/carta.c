#include "carta.h"
#include "colores.h"
#include <stdio.h>

void imprimir_carta(int pal, int num) {
    printf_color_num(pal);
    char *palos[] = {"O", "C", "E", "B"};
    char *figuras[] = {"1", "2", "3", "4", "5", "6", "7", "10", "11", "12"};

    // Asegurar la impresión correcta de la carta según la figura
    if (num >= 0 && num <= 6) {
        printf("[%s%2s]", palos[pal], figuras[num]);
    } else if (num >= 7 && num <= 9) {
        printf("[%s%s]", palos[pal], figuras[num]);
    } else {
        printf("[- -]");
    }

    printf_reset_color();
}
