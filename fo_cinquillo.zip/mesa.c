#include "mesa.h"
#include "carta.h"
#include <stdio.h>

void imprimir_mantel(int mantel[NUM_NUMS][NUM_PALS]) {
    // Encabezado de los palos con espacios adecuados
    printf(" [ORO]   [COP]   [ESP]   [BAS]\n");

    // Imprimir las cartas en el orden adecuado (12, 11, 10, 7, 6, 5, 4, 3, 2, 1)
    int orden_cartas[] = {12, 11, 10, 7, 6, 5, 4, 3, 2, 1};
    int num_cartas = sizeof(orden_cartas) / sizeof(orden_cartas[0]);

    for (int i = 0; i < num_cartas; i++) {
        int num = orden_cartas[i] - 1;  // Restar 1 para que coincida con el índice de la matriz
        for (int pal = 0; pal < NUM_PALS; pal++) {
            if (mantel[num][pal]) {
                // Utilizar la función imprimir_carta de carta.c
                imprimir_carta(pal, orden_cartas[i] - 1);
                printf("   "); // Añadir espacio después de cada carta para alineación
            } else {
                printf("[- -]   "); // Espacio después del marcador de posición vacío
            }
        }
        printf("\n");
    }
}
