// Este fichero se le da al alumno
#ifndef DUERME_H
#define	DUERME_H

void duerme_n_segundos(long segundos);
void duerme_n_nanosegundos(long nanosegundos);
void duerme_un_rato();
void duerme_un_nano_rato();

#endif	/* DUERME_H */

